import { StreamingServer } from '../types';

export const STREAMING_SERVERS: StreamingServer[] = [
  {
    id: 'vidlink',
    name: 'Server 1: VidLink Pro (Fastest 4K)',
    badge: 'RECOMMENDED',
    quality: '4K / 1080p Ultra HD',
    speed: 'Ultra Fast CDN',
    isReliable: true,
    getUrl: (type, id, season = 1, episode = 1) => {
      const base = 'https://vidlink.pro';
      const params = '?primaryColor=e50914&secondaryColor=141414&iconColor=e50914';
      return type === 'movie'
        ? `${base}/movie/${id}${params}`
        : `${base}/tv/${id}/${season}/${episode}${params}`;
    },
  },
  {
    id: 'superembed',
    name: 'Server 2: SuperEmbed VIP',
    badge: 'MULTI-SOURCE',
    quality: '1080p Full HD',
    speed: 'Zero Buffer',
    isReliable: true,
    getUrl: (type, id, season = 1, episode = 1) => {
      return type === 'movie'
        ? `https://superembed.stream/?video_id=${id}&tmdb=1`
        : `https://superembed.stream/?video_id=${id}&tmdb=1&s=${season}&e=${episode}`;
    },
  },
  {
    id: 'vidflix',
    name: 'Server 3: Vidflix Prime',
    badge: 'FAST STREAM',
    quality: '1080p HD',
    speed: 'High Speed CDN',
    isReliable: true,
    getUrl: (type, id, season = 1, episode = 1) => {
      return type === 'movie'
        ? `https://vidsrc.pm/embed/movie?tmdb=${id}`
        : `https://vidsrc.pm/embed/tv?tmdb=${id}&season=${season}&episode=${episode}`;
    },
  },
  {
    id: 'multiembed',
    name: 'Server 4: MultiEmbed HD',
    badge: 'MULTI-AUDIO',
    quality: '1080p / 720p',
    speed: 'Global CDN',
    isReliable: true,
    getUrl: (type, id, season = 1, episode = 1) => {
      return type === 'movie'
        ? `https://multiembed.mov/?video_id=${id}&tmdb=1`
        : `https://multiembed.mov/?video_id=${id}&tmdb=1&s=${season}&e=${episode}`;
    },
  },
  {
    id: '2embed',
    name: 'Server 5: 2Embed Cinema',
    badge: 'CINEMA HQ',
    quality: '1080p HD',
    speed: 'Direct CDN',
    isReliable: true,
    getUrl: (type, id, season = 1, episode = 1) => {
      return type === 'movie'
        ? `https://www.2embed.cc/embed/${id}`
        : `https://www.2embed.cc/embedtv/${id}&s=${season}&e=${episode}`;
    },
  },
  {
    id: 'vidsrc',
    name: 'Server 6: VidSrc Cloud',
    badge: 'BACKUP',
    quality: '1080p HD',
    speed: 'Cloud Mirror',
    isReliable: true,
    getUrl: (type, id, season = 1, episode = 1) => {
      return type === 'movie'
        ? `https://vidsrc.to/embed/movie/${id}`
        : `https://vidsrc.to/embed/tv/${id}/${season}/${episode}`;
    },
  },
];

